/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */

#include "sys/fcntl.h"
